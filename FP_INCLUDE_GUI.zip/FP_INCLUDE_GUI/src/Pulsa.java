
public interface Pulsa {
	void beliPulsa(float saldo);
}
